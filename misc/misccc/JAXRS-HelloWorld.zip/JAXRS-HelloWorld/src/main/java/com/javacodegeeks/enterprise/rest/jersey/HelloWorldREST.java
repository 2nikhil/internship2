package com.javacodegeeks.enterprise.rest.jersey;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;



@Path("/members")
public class HelloWorldREST {

	@POST
	@Path("/info")
	public Response responseMsg(@FormParam("fname") String fname,	@FormParam("lname") String lname ) {

		String output = "This all the info about "+fname +" "+lname;
		return Response.status(200).entity(output).build(); 

	}
}