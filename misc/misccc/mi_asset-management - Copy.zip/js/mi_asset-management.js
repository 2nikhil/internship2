



function getrequest(){
	


	
var settings = {
  "async": true,
  "crossDomain": true,
  "url": "http://localhost:8080/mi_asset-management/rest/assets",
  "method": "GET",
  "headers": {
   // "cache-control": "no-cache",
   // "postman-token": "3da342c4-f4f7-3b51-cd02-0f17f8279637"
  } 
}

$.ajax(settings).done(function (response) {
  console.log(response);
});


}


